<?php get_header(); ?>

      <div class="row">

          <div class="blog-post col-lg-4">
            <h2 class="blog-post-title"><img class="col-12" src="https://cdn.tourcms.com/a/10169/114/2/default.jpg"></h2>
            <p class="blog-post-meta">January 1, 2014 by <a href="#">Sven</a></p>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos esse iste commodi cum sequi ab cupiditate facere, laborum animi, vitae nihil distinctio! Dolorem quaerat, iure hic autem, quia ex rerum!</p>
            <hr>
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
            
<?php
if ( have_posts() ) {
        while ( have_posts() ) {
                the_post();
                //
                // Post Content here
                //
        } // end while
} // end if
?>
          </div><!-- /.blog-post -->

          <div class="blog-post col-lg-4">
            <h2 class="blog-post-title"><img class="col-12" src="https://www.vienna-unwrapped.com/wp-content/uploads/2014/04/Vienna_Attractions_10-660x330.jpg"></h2>
            <p class="blog-post-meta">January 1, 2014 by <a href="#">Sven</a></p>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos esse iste commodi cum sequi ab cupiditate facere, laborum animi, vitae nihil distinctio! Dolorem quaerat, iure hic autem, quia ex rerum!</p>
            <hr>
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
          </div><!-- /.blog-post -->

          <div class="blog-post col-lg-4">
            <h2 class="blog-post-title"><img class="col-12" src="https://www.viennasightseeing.at/application/files/cache/3b2f6849e0bf304eddaff92bd839b53c.jpg"></h2>
            <p class="blog-post-meta">January 1, 2014 by <a href="#">Sven</a></p>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos esse iste commodi cum sequi ab cupiditate facere, laborum animi, vitae nihil distinctio! Dolorem quaerat, iure hic autem, quia ex rerum!</p>
            <hr>
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
          </div><!-- /.blog-post -->
</div><!-- /.row -->

      <div class="row">

          <div class="blog-post col-lg-4">
            <h2 class="blog-post-title"><img class="col-12" src="https://cdn.tourcms.com/a/10169/114/2/default.jpg"></h2>
            <p class="blog-post-meta">January 1, 2014 by <a href="#">Sven</a></p>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos esse iste commodi cum sequi ab cupiditate facere, laborum animi, vitae nihil distinctio! Dolorem quaerat, iure hic autem, quia ex rerum!</p>
            <hr>
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
          </div><!-- /.blog-post -->

          <div class="blog-post col-lg-4">
            <h2 class="blog-post-title"><img class="col-12" src="https://www.vienna-unwrapped.com/wp-content/uploads/2014/04/Vienna_Attractions_10-660x330.jpg"></h2>
            <p class="blog-post-meta">January 1, 2014 by <a href="#">Sven</a></p>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos esse iste commodi cum sequi ab cupiditate facere, laborum animi, vitae nihil distinctio! Dolorem quaerat, iure hic autem, quia ex rerum!</p>
            <hr>
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
          </div><!-- /.blog-post -->

          <div class="blog-post col-lg-4">
            <h2 class="blog-post-title"><img class="col-12" src="https://www.viennasightseeing.at/application/files/cache/3b2f6849e0bf304eddaff92bd839b53c.jpg"></h2>
            <p class="blog-post-meta">January 1, 2014 by <a href="#">Sven</a></p>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos esse iste commodi cum sequi ab cupiditate facere, laborum animi, vitae nihil distinctio! Dolorem quaerat, iure hic autem, quia ex rerum!</p>
            <hr>
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
          </div><!-- /.blog-post -->
</div>

      <div class="row">

          <div class="blog-post col-lg-4">
            <h2 class="blog-post-title"><img class="col-12" src="https://cdn.tourcms.com/a/10169/114/2/default.jpg"></h2>
            <p class="blog-post-meta">January 1, 2014 by <a href="#">Sven</a></p>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos esse iste commodi cum sequi ab cupiditate facere, laborum animi, vitae nihil distinctio! Dolorem quaerat, iure hic autem, quia ex rerum!</p>
            <hr>
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
          </div><!-- /.blog-post -->

          <div class="blog-post col-lg-4">
            <h2 class="blog-post-title"><img class="col-12" src="https://www.vienna-unwrapped.com/wp-content/uploads/2014/04/Vienna_Attractions_10-660x330.jpg"></h2>
            <p class="blog-post-meta">January 1, 2014 by <a href="#">Sven</a></p>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos esse iste commodi cum sequi ab cupiditate facere, laborum animi, vitae nihil distinctio! Dolorem quaerat, iure hic autem, quia ex rerum!</p>
            <hr>
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
          </div><!-- /.blog-post -->

          <div class="blog-post col-lg-4">
            <h2 class="blog-post-title"><img class="col-12" src="https://www.viennasightseeing.at/application/files/cache/3b2f6849e0bf304eddaff92bd839b53c.jpg"></h2>
            <p class="blog-post-meta">January 1, 2014 by <a href="#">Sven</a></p>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos esse iste commodi cum sequi ab cupiditate facere, laborum animi, vitae nihil distinctio! Dolorem quaerat, iure hic autem, quia ex rerum!</p>
            <hr>
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
          </div><!-- /.blog-post -->
</div>

      <div class="row">

          <div class="blog-post col-lg-4">
            <h2 class="blog-post-title"><img class="col-12" src="https://cdn.tourcms.com/a/10169/114/2/default.jpg"></h2>
            <p class="blog-post-meta">January 1, 2014 by <a href="#">Sven</a></p>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos esse iste commodi cum sequi ab cupiditate facere, laborum animi, vitae nihil distinctio! Dolorem quaerat, iure hic autem, quia ex rerum!</p>
            <hr>
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
          </div><!-- /.blog-post -->

          <div class="blog-post col-lg-4">
            <h2 class="blog-post-title"><img class="col-12" src="https://www.vienna-unwrapped.com/wp-content/uploads/2014/04/Vienna_Attractions_10-660x330.jpg"></h2>
            <p class="blog-post-meta">January 1, 2014 by <a href="#">Sven</a></p>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos esse iste commodi cum sequi ab cupiditate facere, laborum animi, vitae nihil distinctio! Dolorem quaerat, iure hic autem, quia ex rerum!</p>
            <hr>
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
          </div><!-- /.blog-post -->

          <div class="blog-post col-lg-4">
            <h2 class="blog-post-title"><img class="col-12" src="https://www.viennasightseeing.at/application/files/cache/3b2f6849e0bf304eddaff92bd839b53c.jpg"></h2>
            <p class="blog-post-meta">January 1, 2014 by <a href="#">Sven</a></p>

            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos esse iste commodi cum sequi ab cupiditate facere, laborum animi, vitae nihil distinctio! Dolorem quaerat, iure hic autem, quia ex rerum!</p>
            <hr>
            <p>Cum sociis natoque penatibus et magnis <a href="#">dis parturient montes</a>, nascetur ridiculus mus. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum. Sed posuere consectetur est at lobortis. Cras mattis consectetur purus sit amet fermentum.</p>
          </div><!-- /.blog-post -->
</div>


    </div><!-- /.container -->
        

        <?php get_sidebar(); ?>

      

<?php get_footer(); ?>