<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <meta name="description" content="<?php bloginfo('description'); ?>">
  <title><?php bloginfo('name'); ?></title>
  <!-- Bootstrap core CSS -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <!-- Custom styles for this template -->
  <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
      <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <?php wp_head(); ?>
</head>
<body>
<nav class="navbar navbar-expand-md navbar-light bg-success m-0" role="navigation" id="navi">

       <div class="container">

      <!-- Brand and toggle get grouped for better mobile display -->

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="Toggle navigation">

          <span class="navbar-toggler-icon"></span>

      </button>

      <a class="navbar-brand" href="#">Mount Everest</a>

          <?php

          wp_nav_menu( array(

              'theme_location'    => 'primary',

              'depth'             => 2, // 1 = no dropdowns, 2 = dropdown

              'container'         => 'div',

              'container_class'   => 'collapse navbar-collapse',

              'container_id'      => 'bs-example-navbar-collapse-1',

              'menu_class'        => 'nav navbar-nav',

              'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',

              'walker'            => new WP_Bootstrap_Navwalker(),

          ) );

          ?>

      </div>

  </nav>


  <section class="showcase">
    <div class="container">
      <h1>Mount Everest Travel Agency</h1>
      <p>Nulla facilisis orci risus, id pharetra urna porta at. Pellentesque erat urna, varius ut mollis quis, ultricies et ante.</p>
      <a class="btn btn-primary btn-lg">Read More</a>
    </div>
  </section>
  <section class="boxes">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="box">
            <i class="fa fa-paper-plane" aria-hidden="true"></i>
            <h3>Lorem Ipsum Dolor</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at. </p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <i class="fa fa-comments" aria-hidden="true"></i>
            <h3>Lorem Ipsum Dolor</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="box">
            <i class="fa fa-power-off" aria-hidden="true"></i>
            <h3>Lorem Ipsum Dolor</h3>
            <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php get_footer(); ?>